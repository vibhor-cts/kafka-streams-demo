
# ReportFormats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reportFormatList** | [**List&lt;ReportFormat&gt;**](ReportFormat.md) |  |  [optional]



