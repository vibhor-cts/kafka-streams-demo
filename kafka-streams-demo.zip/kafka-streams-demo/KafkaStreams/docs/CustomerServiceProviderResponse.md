
# CustomerServiceProviderResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerServiceProvider** | [**CustomerServiceProvider**](CustomerServiceProvider.md) |  |  [optional]



