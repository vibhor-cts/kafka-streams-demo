
# Currency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencyCode** | **String** |  |  [optional]
**currencyName** | **String** |  |  [optional]



