
# StoreMangerPosTerminalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storeMangerPosTerminal** | [**StoreMangerPosTerminal**](StoreMangerPosTerminal.md) |  |  [optional]



