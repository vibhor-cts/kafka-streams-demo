
# PinPad

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pinPadId** | **Integer** | PinPad Id |  [optional]
**providerName** | **String** | provider Name of PinPad |  [optional]
**modelName** | **String** | Model Name of PinPad |  [optional]
**firmWareName** | **String** | FirmWare Name of PinPad |  [optional]
**firmWareVersion** | **String** | FirmWare Version of PinPad |  [optional]
**applicationType** | **String** | Application Type of PinPad |  [optional]
**productType** | **String** | Product Type |  [optional]



