
# AccountManager

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountManagerId** | **Integer** |  |  [optional]
**accountManagerName** | **String** |  |  [optional]



