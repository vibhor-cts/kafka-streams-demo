
# CardIssuersResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardIssuers** | [**CardIssuer**](CardIssuer.md) |  |  [optional]



