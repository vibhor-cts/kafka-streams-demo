
# ProductTypeList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productType** | [**List&lt;ProductType&gt;**](ProductType.md) |  |  [optional]



