
# ProductSalePriceSlabsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productSalePriceSlabs** | [**ProductSalePriceSlabs**](ProductSalePriceSlabs.md) |  |  [optional]



