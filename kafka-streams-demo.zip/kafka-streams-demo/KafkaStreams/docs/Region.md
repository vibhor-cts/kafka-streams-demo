
# Region

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**regionId** | **Integer** |  |  [optional]
**regionNumber** | **String** | Region number |  [optional]
**regionDescription** | **String** | Region Description |  [optional]
**networkUserAddress1** | **String** | Network User Address1 |  [optional]
**networkUserAddress2** | **String** | Network User Address2 |  [optional]
**authorisationPhone1** | **String** | Authorisation Phone1 |  [optional]
**authorisationPhone2** | **String** | Authorisation Phone2 |  [optional]
**team** | **String** | team |  [optional]
**countryCode** | **String** | Iso Country Code |  [optional]



