
# EnforcedLimit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**partyType** | **String** | AID for enforced limits and MID for Emergency limits |  [optional]
**enforcedQualifier** | **String** | SALE for enforced limits and EMERG for Emergency limits |  [optional]



