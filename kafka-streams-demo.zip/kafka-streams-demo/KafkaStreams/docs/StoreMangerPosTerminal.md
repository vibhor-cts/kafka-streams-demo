
# StoreMangerPosTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **String** |  | 
**userName** | **String** |  |  [optional]
**userType** | **String** |  |  [optional]
**typeNumber** | **String** |  |  [optional]
**posTerminalId** | **String** |  |  [optional]



