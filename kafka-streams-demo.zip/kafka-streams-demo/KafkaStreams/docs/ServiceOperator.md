
# ServiceOperator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceId** | **String** | Serivce Id |  [optional]
**serviceProviderName** | **String** | Serivce Provider Name |  [optional]



