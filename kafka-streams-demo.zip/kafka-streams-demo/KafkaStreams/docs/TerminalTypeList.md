
# TerminalTypeList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminalTypeList** | [**List&lt;TerminalType&gt;**](TerminalType.md) |  |  [optional]



