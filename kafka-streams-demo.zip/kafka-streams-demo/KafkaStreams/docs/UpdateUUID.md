
# UpdateUUID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UUID** | **String** |  | 
**MID** | **String** |  | 



