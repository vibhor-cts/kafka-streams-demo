
# ServiceList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service** | [**List&lt;Service&gt;**](Service.md) |  |  [optional]



