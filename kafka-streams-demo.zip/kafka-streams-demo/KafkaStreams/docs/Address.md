
# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addressId** | **Integer** |  |  [optional]
**type** | **String** | Type of Address | 
**entityId** | **Integer** |  |  [optional]
**entityTableName** | **String** | Entity table name |  [optional]
**addressLine1** | **String** | Address part one | 
**addressLine2** | **String** | Address part two |  [optional]
**city** | **String** | City | 
**regionNumber** | **String** | Region number |  [optional]
**zipCode** | **String** | Zip code | 
**isoCountryCode** | **String** | Iso Country Code | 
**countryName** | **String** | Country name |  [optional]
**longitude** | **String** | Longitude |  [optional]
**latitude** | **String** | Latitude |  [optional]



