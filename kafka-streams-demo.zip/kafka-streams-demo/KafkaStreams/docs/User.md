
# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**enabled** | **String** |  |  [optional]
**typeOfUser** | **String** |  |  [optional]
**startDate** | **String** |  |  [optional]
**startTime** | **String** |  |  [optional]
**loggedOn** | **String** |  |  [optional]
**changeDate** | **String** |  |  [optional]
**changeTime** | **String** |  |  [optional]
**forceDays** | **Integer** |  |  [optional]
**lastLogDate** | **String** |  |  [optional]
**lastLogTime** | **String** |  |  [optional]
**retryCount** | **Integer** |  |  [optional]
**role** | **Integer** |  |  [optional]
**typeNumber** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**sentAllow** | **String** | Notification sent allow flag |  [optional]
**emailPassword** | **String** |  |  [optional]
**mobileIdentificationNumber** | **String** |  |  [optional]
**poSTerminalId** | **String** |  |  [optional]
**salt** | **String** |  |  [optional]
**algorithmType** | **String** |  |  [optional]
**notificationHash** | **String** |  |  [optional]
**securityQA** | **String** |  |  [optional]



