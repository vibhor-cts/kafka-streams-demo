
# Countries

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryList** | [**List&lt;Country&gt;**](Country.md) |  |  [optional]



