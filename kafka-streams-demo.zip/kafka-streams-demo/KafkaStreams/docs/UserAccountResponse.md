
# UserAccountResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userResponse** | [**User**](User.md) |  |  [optional]



