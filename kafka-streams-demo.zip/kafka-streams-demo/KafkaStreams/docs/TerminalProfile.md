
# TerminalProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminalProfileId** | **Integer** | Terminal Profile Id |  [optional]
**name** | **String** | Terminal profile name |  [optional]



