
# UserResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | [**List&lt;User&gt;**](User.md) |  |  [optional]



