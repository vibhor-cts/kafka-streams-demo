
# CardIssuerDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardIssuerCode** | **String** | Card Issuer Code |  [optional]
**cardIssuerServiceName** | **String** | Card Issuer Service Name |  [optional]



