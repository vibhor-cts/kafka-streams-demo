
# PosTerminals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminals** | **List&lt;String&gt;** |  |  [optional]



