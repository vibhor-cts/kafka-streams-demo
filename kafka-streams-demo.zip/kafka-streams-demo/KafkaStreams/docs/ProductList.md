
# ProductList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productList** | [**List&lt;Product&gt;**](Product.md) |  |  [optional]



