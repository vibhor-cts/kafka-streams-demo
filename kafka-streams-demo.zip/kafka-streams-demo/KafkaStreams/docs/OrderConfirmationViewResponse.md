
# OrderConfirmationViewResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fileContent** | **String** | return a file |  [optional]



