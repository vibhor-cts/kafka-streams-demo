
# RegionListResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**regionList** | [**List&lt;Region&gt;**](Region.md) |  |  [optional]



