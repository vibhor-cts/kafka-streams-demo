
# ProductSalePriceGroupResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productSalePriceGroup** | [**ProductSalePriceGroup**](ProductSalePriceGroup.md) |  |  [optional]



