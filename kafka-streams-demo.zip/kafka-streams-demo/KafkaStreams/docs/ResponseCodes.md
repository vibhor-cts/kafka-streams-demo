
# ResponseCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseCode** | [**List&lt;ResponseCode&gt;**](ResponseCode.md) |  |  [optional]



