
# TerminalType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminalTypeId** | **Integer** | Terminal Type Id |  [optional]
**description** | **String** | Description Of Terminal Type |  [optional]
**manufacturerCode** | **Integer** | Manufacturer Code |  [optional]
**modemType** | **String** | Modem Type |  [optional]
**turnOnTime** | **Integer** | Turn On Time |  [optional]
**transactionMode** | **String** | transactionMode |  [optional]
**transactionSequenceFlag** | **String** | Transaction Sequence Flag |  [optional]



