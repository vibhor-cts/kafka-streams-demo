
# CustomerServiceProviders

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerServiceProviderList** | [**List&lt;CustomerServiceProvider&gt;**](CustomerServiceProvider.md) |  |  [optional]



