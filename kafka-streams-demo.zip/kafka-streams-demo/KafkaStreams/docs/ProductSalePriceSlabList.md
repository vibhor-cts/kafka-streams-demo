
# ProductSalePriceSlabList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productSalePriceSlabList** | [**List&lt;ProductSalePriceSlabs&gt;**](ProductSalePriceSlabs.md) |  |  [optional]



