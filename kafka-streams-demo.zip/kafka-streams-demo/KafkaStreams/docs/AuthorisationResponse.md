
# AuthorisationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**apiAuthorisation** | [**Authorisation**](Authorisation.md) |  |  [optional]



