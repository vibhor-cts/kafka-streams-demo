
# OrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderProducts** | [**List&lt;OrderProduct&gt;**](OrderProduct.md) |  |  [optional]



