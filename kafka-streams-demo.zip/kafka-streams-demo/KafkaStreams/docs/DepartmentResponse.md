
# DepartmentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**departmentNumber** | **Integer** |  |  [optional]



