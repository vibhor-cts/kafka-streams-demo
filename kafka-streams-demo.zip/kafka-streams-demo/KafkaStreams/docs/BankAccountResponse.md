
# BankAccountResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankAccount** | [**BankAccount**](BankAccount.md) |  |  [optional]



