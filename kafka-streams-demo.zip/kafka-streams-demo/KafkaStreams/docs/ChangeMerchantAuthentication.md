
# ChangeMerchantAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **String** | User ID | 
**userName** | **String** | User Name |  [optional]
**authentication** | **String** | User New Password |  [optional]
**confirmAuthentication** | **String** | User Confirm Password |  [optional]
**role** | **Integer** | Role |  [optional]



