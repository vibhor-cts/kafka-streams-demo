
# MerchantsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchants** | [**List&lt;Merchant&gt;**](Merchant.md) |  |  [optional]



