
# Country

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isOCountryCode** | **String** |  |  [optional]
**isOCountryName** | **String** |  |  [optional]



