
# ProductPlanPriceResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productPlanPrice** | [**ProductPlanPrice**](ProductPlanPrice.md) |  |  [optional]
**price** | **String** | Order price |  [optional]
**vatAmount** | **String** | Vat amount |  [optional]
**netAmount** | **String** | Net amount |  [optional]



