
# ReportFormat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**formatCode** | **Integer** |  |  [optional]
**formatDescription** | **String** | Report Format Description |  [optional]



