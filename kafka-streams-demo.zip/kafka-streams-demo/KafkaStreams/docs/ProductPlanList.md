
# ProductPlanList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productPlanList** | [**List&lt;ProductPlan&gt;**](ProductPlan.md) |  |  [optional]



