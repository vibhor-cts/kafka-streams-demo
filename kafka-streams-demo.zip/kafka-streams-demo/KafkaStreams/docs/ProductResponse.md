
# ProductResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product** | [**Product**](Product.md) |  |  [optional]



