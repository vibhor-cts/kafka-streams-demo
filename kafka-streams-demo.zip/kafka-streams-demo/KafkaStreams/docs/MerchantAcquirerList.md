
# MerchantAcquirerList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantAcquirerList** | [**List&lt;MerchantAcquirer&gt;**](MerchantAcquirer.md) |  |  [optional]



