
# ProcessManagementStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processType** | **String** | Process type |  [optional]
**action** | **String** | Action to be performed |  [optional]
**updDate** | **String** | Update Date |  [optional]



