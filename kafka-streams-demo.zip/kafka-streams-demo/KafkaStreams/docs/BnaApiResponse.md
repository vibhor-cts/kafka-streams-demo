
# BnaApiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**apiCode** | **Integer** | Api Code | 
**apiMessage** | **String** | Api Message |  [optional]



