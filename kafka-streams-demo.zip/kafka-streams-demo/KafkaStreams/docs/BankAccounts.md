
# BankAccounts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankAccounts** | [**List&lt;BankAccount&gt;**](BankAccount.md) |  |  [optional]



