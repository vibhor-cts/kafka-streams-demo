
# TermAttributeRules

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**termAttributeRulesId** | **Integer** | Terminal Attribute Rules Id |  [optional]
**terminalPositionNo** | **Integer** | Terminal Position Number |  [optional]
**terminalValueNo** | **Integer** | Terminal Value Number |  [optional]
**description** | **String** | Description |  [optional]
**terminalWeight** | **Integer** | Terminal Weight |  [optional]
**enabled** | **Boolean** |  |  [optional]
**checked** | **Boolean** |  |  [optional]



