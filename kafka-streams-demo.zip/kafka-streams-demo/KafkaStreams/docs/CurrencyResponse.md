
# CurrencyResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | [**List&lt;Currency&gt;**](Currency.md) |  |  [optional]



