
# TerminalAttributeRulesList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**termAttributeRules** | [**List&lt;TermAttributeRules&gt;**](TermAttributeRules.md) |  |  [optional]



