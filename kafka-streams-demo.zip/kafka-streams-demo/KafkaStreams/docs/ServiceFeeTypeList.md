
# ServiceFeeTypeList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceFeeType** | [**List&lt;ServiceFeeType&gt;**](ServiceFeeType.md) |  |  [optional]



