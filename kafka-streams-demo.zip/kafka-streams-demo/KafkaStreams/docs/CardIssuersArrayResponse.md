
# CardIssuersArrayResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardIssuers** | [**List&lt;CardIssuer&gt;**](CardIssuer.md) |  |  [optional]



