
# CardIssuerDetailList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardissuerdetails** | [**List&lt;CardIssuerDetail&gt;**](CardIssuerDetail.md) |  |  [optional]



