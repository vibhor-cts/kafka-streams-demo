
# Authorisations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**apiAuthorisation** | [**List&lt;Authorisation&gt;**](Authorisation.md) |  |  [optional]



