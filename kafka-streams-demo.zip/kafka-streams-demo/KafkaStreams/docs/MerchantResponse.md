
# MerchantResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchant** | [**Merchant**](Merchant.md) |  |  [optional]



