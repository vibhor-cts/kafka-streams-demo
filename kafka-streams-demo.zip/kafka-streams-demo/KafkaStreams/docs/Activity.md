
# Activity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activityCode** | **Integer** |  |  [optional]
**description** | **String** |  |  [optional]



