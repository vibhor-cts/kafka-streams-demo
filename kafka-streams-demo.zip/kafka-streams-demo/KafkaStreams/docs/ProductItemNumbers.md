
# ProductItemNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productItemNumber** | **List&lt;Integer&gt;** |  |  [optional]



