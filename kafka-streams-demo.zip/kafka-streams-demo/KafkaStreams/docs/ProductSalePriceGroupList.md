
# ProductSalePriceGroupList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productSalePriceGroup** | [**List&lt;ProductSalePriceGroup&gt;**](ProductSalePriceGroup.md) |  |  [optional]



