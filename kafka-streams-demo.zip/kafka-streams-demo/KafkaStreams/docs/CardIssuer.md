
# CardIssuer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardIssuerId** | **Integer** |  |  [optional]
**code** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**nameAbbreviation** | **String** |  |  [optional]
**facilityCode** | **String** |  |  [optional]
**upperFloorLimit** | **Long** |  |  [optional]
**cyclicFloorLimit** | **Long** |  |  [optional]
**cyclicCount** | **Long** |  |  [optional]
**floorLimit** | **Long** |  |  [optional]
**ceilingLimit** | **Long** |  |  [optional]
**minimumTransactionAmount** | **Long** |  |  [optional]
**mode** | **String** |  |  [optional]
**changeNumber** | **Long** |  |  [optional]
**issuerImageName** | **String** |  |  [optional]



