
# TerminalProfileArrayResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminalProfiles** | [**List&lt;TerminalProfile&gt;**](TerminalProfile.md) |  |  [optional]



