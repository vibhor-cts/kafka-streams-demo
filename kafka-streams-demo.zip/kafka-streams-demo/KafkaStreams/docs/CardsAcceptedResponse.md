
# CardsAcceptedResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardsAccepted** | [**CardsAccepted**](CardsAccepted.md) |  |  [optional]



