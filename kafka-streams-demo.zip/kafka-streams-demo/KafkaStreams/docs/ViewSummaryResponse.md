
# ViewSummaryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityTypeNumber** | **String** | Entity Type Can be Customer-Code/Merchant/Agent Number/Terminal Id |  [optional]
**merchantCount** | **Integer** |  |  [optional]
**agentCount** | **Integer** |  |  [optional]
**terminalCount** | **Integer** |  |  [optional]
**registrationDate** | **String** | Registration date |  [optional]
**terminalStatisticsList** | [**List&lt;TerminalStatistic&gt;**](TerminalStatistic.md) |  |  [optional]



