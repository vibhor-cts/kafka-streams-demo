
# ProcessStatusResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**processStatus** | [**ProcessStatusObject**](ProcessStatusObject.md) |  |  [optional]



