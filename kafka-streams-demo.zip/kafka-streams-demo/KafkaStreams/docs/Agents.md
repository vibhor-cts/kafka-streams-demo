
# Agents

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agents** | [**List&lt;Agent&gt;**](Agent.md) |  |  [optional]



