
# TransactionPerMonthOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **String** |  |  [optional]
**value** | **String** |  |  [optional]



