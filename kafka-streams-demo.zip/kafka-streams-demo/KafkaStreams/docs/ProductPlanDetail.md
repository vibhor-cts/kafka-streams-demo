
# ProductPlanDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productSalePriceSlabs** | [**List&lt;ProductSalePriceSlabs&gt;**](ProductSalePriceSlabs.md) |  |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]



