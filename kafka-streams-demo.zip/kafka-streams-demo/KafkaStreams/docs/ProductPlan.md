
# ProductPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productPlanId** | **Integer** | Product Plan Id |  [optional]
**code** | **String** | Product Plan Code | 
**fromDate** | [**LocalDate**](LocalDate.md) | From Date | 
**toDate** | [**LocalDate**](LocalDate.md) | To Date |  [optional]
**name** | **String** | Product Plan Name | 
**nominalCode** | **String** | Product Plan Nominal Code |  [optional]
**taxCode** | **Integer** | Product Plan Tax Code |  [optional]
**status** | **String** | Product Plan Status | 



