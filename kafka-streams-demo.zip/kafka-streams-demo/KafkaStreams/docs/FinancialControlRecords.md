
# FinancialControlRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**financialControlRecords** | [**List&lt;FinancialControlRecord&gt;**](FinancialControlRecord.md) |  |  [optional]



