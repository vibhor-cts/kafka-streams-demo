
# PinPadList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pinPad** | [**List&lt;PinPad&gt;**](PinPad.md) |  |  [optional]



