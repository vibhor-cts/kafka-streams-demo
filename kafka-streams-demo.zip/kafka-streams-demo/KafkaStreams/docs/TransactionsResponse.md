
# TransactionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactions** | [**List&lt;Transaction&gt;**](Transaction.md) |  |  [optional]



