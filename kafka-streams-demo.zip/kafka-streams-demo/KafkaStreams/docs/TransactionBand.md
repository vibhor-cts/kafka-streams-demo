
# TransactionBand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionPerMonthOptions** | [**List&lt;TransactionPerMonthOptions&gt;**](TransactionPerMonthOptions.md) |  |  [optional]
**terminalTypeId** | **Integer** |  |  [optional]
**internetPlan** | **String** |  |  [optional]
**transactionPerMonth** | **String** |  |  [optional]



