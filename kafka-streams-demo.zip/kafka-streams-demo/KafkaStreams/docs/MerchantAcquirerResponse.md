
# MerchantAcquirerResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantAcquirer** | [**MerchantAcquirer**](MerchantAcquirer.md) |  |  [optional]



