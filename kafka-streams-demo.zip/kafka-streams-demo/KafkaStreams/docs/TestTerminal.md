
# TestTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminal** | [**Terminal**](Terminal.md) |  | 
**cardsAccepted** | [**CardsAccepted**](CardsAccepted.md) |  | 



