
# Banks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**banks** | [**List&lt;Bank&gt;**](Bank.md) |  |  [optional]



