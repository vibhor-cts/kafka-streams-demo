
# TerminalStatistic

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**yearMonth** | **String** |  |  [optional]
**saleTransactionsCount** | **Integer** |  |  [optional]
**saleTransactionsValue** | **Float** | netAmount |  [optional]
**saleTransactionsGratuityAmount** | **Float** | netAmount |  [optional]
**saleTransactionsServiceCharge** | **Float** | netAmount |  [optional]
**cashBackTransactionsCount** | **Integer** |  |  [optional]
**cashBackTransactionsValue** | **Float** | netAmount |  [optional]
**cashBackTransactionsGratuityAmount** | **Float** | netAmount |  [optional]
**cashBackTransactionsServiceCharge** | **Float** | netAmount |  [optional]
**refundTransactionsCount** | **Integer** |  |  [optional]
**refundTransactionsValue** | **Float** | netAmount |  [optional]
**refundTransactionsGratuityAmount** | **Float** | netAmount |  [optional]
**refundTransactionsServiceCharge** | **Float** | netAmount |  [optional]
**cancelTransactionsCount** | **Integer** |  |  [optional]
**cancelTransactionsValue** | **Float** | netAmount |  [optional]
**cancelTransactionsGratuityAmount** | **Float** | netAmount |  [optional]
**cancelTransactionsServiceCharge** | **Float** | netAmount |  [optional]
**cashAdvanceTransactionsCount** | **Integer** |  |  [optional]
**cashAdvanceTransactionsValue** | **Float** | netAmount |  [optional]
**cashAdvanceTransactionsGratuityAmount** | **Float** | netAmount |  [optional]
**cashAdvanceTransactionsServiceCharge** | **Float** | netAmount |  [optional]
**etopUpTransactionsCount** | **Integer** |  |  [optional]
**etopUpTransactionsValue** | **Float** | netAmount |  [optional]
**etopUpTransactionsGratuityAmount** | **Float** | netAmount |  [optional]
**etopUpTransactionsServiceCharge** | **Float** | netAmount |  [optional]
**totalGratuity** | **Float** | netAmount |  [optional]
**totalServiceCharge** | **Float** | netAmount |  [optional]



