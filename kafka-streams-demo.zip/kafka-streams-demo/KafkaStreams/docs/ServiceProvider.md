
# ServiceProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceCode** | **String** | Service Code |  [optional]
**serviceName** | **String** | Service Name |  [optional]



