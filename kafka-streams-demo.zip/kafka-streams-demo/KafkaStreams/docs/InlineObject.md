
# InlineObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantProcessFile** | [**File**](File.md) |  |  [optional]
**merchantAgreementFile** | [**File**](File.md) |  |  [optional]



