
# Terminals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminalList** | [**List&lt;Terminal&gt;**](Terminal.md) |  |  [optional]



