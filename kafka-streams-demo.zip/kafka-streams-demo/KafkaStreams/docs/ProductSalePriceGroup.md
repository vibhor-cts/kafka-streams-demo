
# ProductSalePriceGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productSalePriceGroupId** | **Integer** | Product Sale Price Group ID | 
**groupName** | **String** | Price Group Name | 
**productCode** | **String** | Product Code | 
**productName** | **String** | Product Name |  [optional]
**entityType** | **String** | Entity Type | 



