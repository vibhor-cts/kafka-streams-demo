
# ResponseCode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseCode** | **String** | reponse code |  [optional]
**responseDescription** | **String** | response code description |  [optional]



