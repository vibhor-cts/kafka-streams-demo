
# CardsAcceptedArrayResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardsAccepted** | [**List&lt;CardsAccepted&gt;**](CardsAccepted.md) |  |  [optional]



