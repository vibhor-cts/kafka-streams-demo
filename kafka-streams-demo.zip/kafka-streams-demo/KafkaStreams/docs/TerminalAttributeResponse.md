
# TerminalAttributeResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminalAttribute** | **String** | Terminal Attribute. |  [optional]



