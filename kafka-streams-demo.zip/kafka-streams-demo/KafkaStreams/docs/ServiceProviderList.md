
# ServiceProviderList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service** | [**List&lt;ServiceProvider&gt;**](ServiceProvider.md) |  |  [optional]



