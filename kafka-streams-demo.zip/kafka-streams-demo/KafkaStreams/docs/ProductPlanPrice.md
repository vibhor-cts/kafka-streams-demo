
# ProductPlanPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerCode** | **String** | Customer Code |  [optional]
**quantity** | **Integer** | Quantity |  [optional]
**transactionCountPerMonth** | **String** | Transaction count per month range |  [optional]
**productDetails** | [**List&lt;ProductDetail&gt;**](ProductDetail.md) |  |  [optional]



