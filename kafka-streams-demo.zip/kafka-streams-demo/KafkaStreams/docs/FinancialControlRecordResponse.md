
# FinancialControlRecordResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**financialControlRecord** | [**FinancialControlRecord**](FinancialControlRecord.md) |  |  [optional]



