
# ProductType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productTypeId** | **Integer** | Product Type ID |  [optional]
**productCode** | **String** | Product Code |  [optional]
**name** | **String** | Product Plan Name |  [optional]
**description** | **String** | Product Type Description |  [optional]



