
# Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contactId** | **Integer** | Contact Type Id |  [optional]
**firstName** | **String** | First name | 
**middleName** | **String** | Middle name |  [optional]
**lastName** | **String** | Last name |  [optional]
**title** | **String** | Title |  [optional]
**phone** | **String** | Phone number | 
**faxNo** | **String** | Fax number |  [optional]
**email** | **String** | Email address |  [optional]
**mobileNumber** | **String** | Mobile number |  [optional]
**tpsRegistered** | **String** | TPS registered |  [optional]
**websiteUrl** | **String** | Website url |  [optional]
**twitterUrl** | **String** | Twitter url |  [optional]
**fBUrl** | **String** | Facebook url |  [optional]
**secondaryPhone** | **String** | Secondary phone number |  [optional]
**address** | [**Address**](Address.md) |  | 



