
# ProductPlanDetailResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acquirerMid** | **String** | sourceId |  [optional]
**vatAmount** | **String** | vatAmount |  [optional]
**netAmount** | **String** | netAmount |  [optional]
**transactionCountPerMonth** | **String** | txnCount |  [optional]
**price** | **String** | price |  [optional]
**quantity** | **String** | quantity |  [optional]
**acquirerMidPrefix** | **String** | sourceIdPrefix |  [optional]
**productPlanDetail** | [**List&lt;ProductPlanDetail&gt;**](ProductPlanDetail.md) |  |  [optional]



