
# TokenPolicyResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokenpolicies** | [**List&lt;TokenPolicy&gt;**](TokenPolicy.md) |  |  [optional]



