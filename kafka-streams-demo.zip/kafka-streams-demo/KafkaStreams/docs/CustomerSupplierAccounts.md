
# CustomerSupplierAccounts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerSupplierAccountList** | [**List&lt;CustomerSupplierAccount&gt;**](CustomerSupplierAccount.md) |  |  [optional]



