
# ProductPlanResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productPlan** | [**ProductPlan**](ProductPlan.md) |  |  [optional]



