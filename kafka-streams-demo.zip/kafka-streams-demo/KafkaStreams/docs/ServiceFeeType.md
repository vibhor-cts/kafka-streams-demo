
# ServiceFeeType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceFeeTypeId** | **Integer** | service Fee Type Id |  [optional]
**code** | **String** | code |  [optional]
**serviceId** | **Integer** | service Id |  [optional]
**serviceName** | **String** | service Name |  [optional]
**feeName** | **String** | fee Name |  [optional]
**type** | **String** | type |  [optional]
**period** | **String** | period |  [optional]
**weekDays** | **String** | week Days |  [optional]
**monthDate** | **Integer** | month Date |  [optional]
**month** | **Integer** | month |  [optional]
**billEntity** | **String** | bill Entity |  [optional]



