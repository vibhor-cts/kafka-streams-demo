
# BankResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bank** | [**Bank**](Bank.md) |  |  [optional]



