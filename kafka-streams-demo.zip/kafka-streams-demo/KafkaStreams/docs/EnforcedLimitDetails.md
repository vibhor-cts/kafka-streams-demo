
# EnforcedLimitDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentSchemeName** | **String** | Scheme |  [optional]



