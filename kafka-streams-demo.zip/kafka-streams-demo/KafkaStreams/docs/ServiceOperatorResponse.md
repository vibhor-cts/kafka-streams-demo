
# ServiceOperatorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serviceIds** | [**List&lt;ServiceOperator&gt;**](ServiceOperator.md) |  |  [optional]



