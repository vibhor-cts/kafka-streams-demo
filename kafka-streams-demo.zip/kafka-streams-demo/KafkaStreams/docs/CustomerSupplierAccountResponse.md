
# CustomerSupplierAccountResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerSupplierAccount** | [**CustomerSupplierAccount**](CustomerSupplierAccount.md) |  |  [optional]



